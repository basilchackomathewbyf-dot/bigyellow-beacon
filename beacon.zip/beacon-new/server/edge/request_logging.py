"""
Request / response logging for the edge server.

One JSON line per request to stdout and logs/edge_requests.log (rotating, 10 MB x 5):
time, client IP, user agent, method, path, query, user (role, vessel, opaque user key),
request input, response status, size and duration.

Deliberately NOT logged, to keep crew reports anonymous and credentials safe:
- passwords, PINs, tokens and secrets (redacted wherever they appear)
- crew names or IDs: the user is an opaque HMAC key, stable per person, so usage can be
  counted and traced per user without the log naming anyone
- photo and audio bytes (only file name, type and size)
- wellbeing check-in text (only the fact that a request was made)
- response bodies (status, size and duration only)
"""

import hashlib
import hmac
import json
import logging
import sys
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path
from urllib.parse import parse_qsl, urlencode

from config import JWT_SECRET_KEY
from security import decode_edge_session_token

LOG_DIR = Path(__file__).resolve().parent / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

logger = logging.getLogger("beacon.edge.requests")
logger.setLevel(logging.INFO)
logger.propagate = False
if not logger.handlers:
    _fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    _console = logging.StreamHandler(sys.stdout)
    _console.setFormatter(_fmt)
    _file = RotatingFileHandler(LOG_DIR / "edge_requests.log", maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8")
    _file.setFormatter(_fmt)
    logger.addHandler(_console)
    logger.addHandler(_file)

MAX_BODY_LOG = 2000  # characters of request input kept per line
SECRET_KEYS = ("password", "pin", "token", "secret", "authorization", "api_key", "pairing_code")
PRIVATE_PATHS = ("/checkins", "/welfare")  # wellbeing content is never logged


def _is_secret(key: str) -> bool:
    k = key.lower()
    return any(s in k for s in SECRET_KEYS)


def _redact(value):
    if isinstance(value, dict):
        return {k: ("[REDACTED]" if _is_secret(k) else _redact(v)) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact(v) for v in value]
    return value


def _user(headers: dict, query: str) -> dict:
    token = None
    auth = headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        token = auth[7:].strip()
    else:
        token = dict(parse_qsl(query)).get("token")
    payload = decode_edge_session_token(token) if token else None
    if not payload:
        return {"auth": "none" if not token else "invalid"}
    person = str(payload.get("crew_id") or payload.get("sub") or "")
    key = hmac.new(JWT_SECRET_KEY.encode(), person.encode(), hashlib.sha256).hexdigest()[:12] if person else None
    return {"role": payload.get("role"), "vessel": payload.get("vessel_id"), "user_key": key}


def _input(path: str, content_type: str, body: bytes, truncated: bool):
    if any(p in path for p in PRIVATE_PATHS):
        return "[wellbeing content not logged]" if body else None
    if not body:
        return None
    ct = content_type.lower()
    if ct.startswith("multipart/form-data"):
        # Summarise fields and files without logging file bytes.
        parts = []
        for chunk in body.split(b"\r\n--"):
            head = chunk.split(b"\r\n\r\n", 1)[0].decode("latin-1", "replace")
            if 'name="' not in head:
                continue
            name = head.split('name="', 1)[1].split('"', 1)[0]
            if 'filename="' in head:
                fname = head.split('filename="', 1)[1].split('"', 1)[0]
                ftype = head.split("Content-Type:", 1)[1].split("\r\n", 1)[0].strip() if "Content-Type:" in head else ""
                size = len(chunk.split(b"\r\n\r\n", 1)[1]) if b"\r\n\r\n" in chunk else 0
                parts.append({"field": name, "file": fname, "type": ftype, "bytes": size})
            elif _is_secret(name):
                parts.append({"field": name, "value": "[REDACTED]"})
            else:
                value = chunk.split(b"\r\n\r\n", 1)[1].decode("utf-8", "replace") if b"\r\n\r\n" in chunk else ""
                parts.append({"field": name, "value": value[:500]})
        return {"multipart": parts, "truncated": truncated} if truncated else {"multipart": parts}
    text = body.decode("utf-8", "replace")
    if "json" in ct:
        try:
            return _redact(json.loads(text))
        except ValueError:
            pass
    if "x-www-form-urlencoded" in ct:
        return _redact(dict(parse_qsl(text)))
    return text[:MAX_BODY_LOG] + ("…" if truncated or len(text) > MAX_BODY_LOG else "")


class RequestLoggingMiddleware:
    """Pure ASGI, so the body is captured as it streams through without being buffered twice."""

    CAPTURE_LIMIT = 64 * 1024  # bytes of request body inspected; uploads beyond this are only sized

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)

        start = time.perf_counter()
        headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope.get("headers", [])}
        captured = bytearray()
        total_in = 0
        status = {"code": 500, "bytes": 0}

        async def receive_wrapper():
            nonlocal total_in
            message = await receive()
            if message["type"] == "http.request":
                chunk = message.get("body", b"")
                total_in += len(chunk)
                room = self.CAPTURE_LIMIT - len(captured)
                if room > 0:
                    captured.extend(chunk[:room])
            return message

        async def send_wrapper(message):
            if message["type"] == "http.response.start":
                status["code"] = message["status"]
            elif message["type"] == "http.response.body":
                status["bytes"] += len(message.get("body", b""))
            await send(message)

        error = None
        try:
            await self.app(scope, receive_wrapper, send_wrapper)
        except Exception as exc:
            error = repr(exc)
            raise
        finally:
            path = scope.get("path", "")
            query = scope.get("query_string", b"").decode("latin-1")
            safe_query = urlencode([(k, "[REDACTED]" if _is_secret(k) else v) for k, v in parse_qsl(query)])
            entry = {
                "ip": (headers.get("x-forwarded-for", "").split(",")[0].strip()
                       or (scope.get("client") or ("unknown",))[0]),
                "ua": headers.get("user-agent"),
                "method": scope.get("method"),
                "path": path,
                "query": safe_query or None,
                "user": _user(headers, query),
                "input": _input(path, headers.get("content-type", ""), bytes(captured), total_in > len(captured)),
                "input_bytes": total_in,
                "status": status["code"],
                "response_bytes": status["bytes"],
                "ms": round((time.perf_counter() - start) * 1000, 1),
            }
            if error:
                entry["error"] = error
            line = json.dumps(entry, ensure_ascii=False, default=str)
            if status["code"] >= 500 or error:
                logger.error(line)
            elif status["code"] >= 400:
                logger.warning(line)
            else:
                logger.info(line)
