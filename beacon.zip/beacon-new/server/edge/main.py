"""
BigYellow Beacon – Edge Server (FastAPI)
Runs shipboard on mini-PC / Jetson LAN.
Zero persistent internet dependency.
"""

from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from config import PORT, HOST, DEBUG, VESSEL_ID, ROOT_PATH
from db import init_edge_db
from middleware.idempotency import IdempotencyMiddleware
from request_logging import RequestLoggingMiddleware
from routes.auth_routes import router as auth_router
from routes.reports_routes import router as reports_router, REQUEST_BASE_URL
from routes.master_routes import router as master_router
from routes.ticket_messages_routes import router as ticket_messages_router
from routes.inbox_routes import router as inbox_router
from routes.events_routes import router as events_router
from routes.checkin_routes import router as checkin_router
import asyncio
from routes.learnings_routes import router as learnings_router
from routes.sync_routes import router as sync_router
from services.sync_worker import sync_worker


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_edge_db()
    print("================================================================")
    print(f"⚓ BigYellow Beacon Edge Server Running for Vessel: {VESSEL_ID}")
    print(f"📡 Local Port: http://{HOST}:{PORT}")
    print(f"📄 Swagger UI: http://{HOST}:{PORT}{ROOT_PATH}/docs")
    print("================================================================")
    # Launch autonomous Edge-to-Shore sync engine in background
    sync_task = asyncio.create_task(sync_worker.run_forever())
    yield
    sync_task.cancel()
    try:
        await sync_task
    except asyncio.CancelledError:
        pass


app = FastAPI(
    title=f"BigYellow Beacon Edge ({VESSEL_ID})",
    version="2.0.0",
    description="Shipboard edge safety intelligence server operating with 0 persistent internet.",
    root_path=ROOT_PATH,
    lifespan=lifespan,
)


# Exception handler returning uniform { "error": "...", ... }
@app.exception_handler(StarletteHTTPException)
async def custom_http_exception_handler(request: Request, exc: StarletteHTTPException):
    if isinstance(exc.detail, dict):
        return JSONResponse(status_code=exc.status_code, content=exc.detail)
    return JSONResponse(status_code=exc.status_code, content={"error": str(exc.detail)})


# Idempotency Middleware for all edge writes
app.add_middleware(IdempotencyMiddleware)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3001",
        "https://beacon.bigyellow.ai",
        "https://beacon-dashboard.bigyellow.ai",
        "https://beacon-ws.bigyellow.ai",
    ],
    allow_origin_regex=r"^https?://([a-zA-Z0-9-]+\.)*(bigyellow\.ai|sslip\.io|localhost|127\.0\.0\.1)(:[0-9]+)?$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Uploaded photos and voice notes. Served by plain routes rather than StaticFiles mounts:
# behind the proxy (prefix stripped, root_path=/api/edge) the mounts returned 404 while
# routes kept working. FileResponse answers Range requests, so audio can seek.
UPLOADS_DIR = Path(__file__).resolve().parent / "uploads"
UPLOADS_DIR.mkdir(parents=True, exist_ok=True)


async def serve_upload(name: str):
    path = UPLOADS_DIR / Path(name).name  # basename only: no path traversal
    if not path.is_file():
        raise StarletteHTTPException(status_code=404, detail="Not Found")
    return FileResponse(path, headers={"Access-Control-Allow-Origin": "*"})


for _prefix in ("/uploads", "/media", "/api/v1/uploads"):
    app.add_api_route(f"{_prefix}/{{name}}", serve_upload, methods=["GET", "HEAD"], include_in_schema=False)


class RequestBaseUrlMiddleware:
    """Records the public base URL of each request for routes.reports_routes.to_public_url."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http":
            headers = {k.decode("latin-1"): v.decode("latin-1") for k, v in scope.get("headers", [])}
            proto = headers.get("x-forwarded-proto", scope.get("scheme", "http")).split(",")[0].strip()
            host = headers.get("x-forwarded-host") or headers.get("host")
            if host:
                token = REQUEST_BASE_URL.set(f"{proto}://{host.split(',')[0].strip()}{scope.get('root_path', '')}")
                try:
                    return await self.app(scope, receive, send)
                finally:
                    REQUEST_BASE_URL.reset(token)
        return await self.app(scope, receive, send)


app.add_middleware(RequestBaseUrlMiddleware)
# Added last so it is outermost: logs every request, including ones other middleware rejects.
app.add_middleware(RequestLoggingMiddleware)

# Mount Routes both at root and with /api/v1 prefix for direct Lovable SDK compatibility
edge_routers = (
    auth_router,
    reports_router,
    master_router,
    ticket_messages_router,
    inbox_router,
    events_router,
    checkin_router,
    learnings_router,
    sync_router,
)
for r in edge_routers:
    app.include_router(r)
    app.include_router(r, prefix="/api/v1")


@app.get("/edge/docs", include_in_schema=False)
@app.get("/edge", include_in_schema=False)
def edge_docs_redirect():
    return RedirectResponse(url="/docs")


@app.get("/health", tags=["System"])
@app.get("/healthz", tags=["System"])
def edge_health():
    return {
        "status": "online",
        "plane": "edge",
        "vessel_id": VESSEL_ID,
        "engine": "FastAPI + SQLite/Postgres (SQLAlchemy 2)",
    }
