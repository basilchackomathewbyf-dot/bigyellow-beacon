# BigYellow Beacon (monorepo)

Crew safety and wellbeing platform for merchant ships. Crew report near-misses on board (offline); the shore safety team reviews them in the **Beacon Dashboard**, gets Gemini analysis, replies anonymously, and publishes microlearnings and Daily Anchor cards back to vessels.

Design doc: `docs/technical-design.md` (exported from "BigYellow Beacon POC: Technical Design").
**It is not in the repo — `docs/` holds only a `.gitkeep`.** Until it is added, these
CLAUDE.md files are the contract. If code and doc disagree, flag it; don't silently pick one.

## What is in scope now
| Folder | What it is | Status |
| --- | --- | --- |
| `apps/beacon-dashboard` | Shore web app for the fleet safety team (React) | **Active** |
| `services/shore-api` | Shore backend for the dashboard and, later, ship sync (FastAPI) | **Active** |
| `apps/crew-app` | Crew + Master PWA used on board | Future, do not touch |
| `services/edge-server` | On-board server with Gemma | Future, do not touch |

Current goal: **Beacon Dashboard + shore-api working end to end with real Gemini.**

The three AI use cases the dashboard needs are **done and verified live**:
1. AI ticket analysis and summary
2. Related tickets from the same or other vessels (embedding similarity)
3. AI-generated microlearning from a specific ticket

Still open: AI media generation (Imagen/Veo — built, but needs Vertex AI rather
than a Gemini API key, and has no UI control), and the Daily Anchor screen (API
and client layer done, no UI).

## Naming (use these words everywhere: code, commits, UI, docs)
- **Beacon Dashboard**: the shore web app. Never "crew hub", "admin panel" or "portal".
- **shore-api**: the shore FastAPI service. Python package name `shore_api`.
- **crew-app**: the on-board PWA (Crew and Master roles).
- **edge-server**: the on-board FastAPI service.
- **Ticket**: one near-miss report. Number format `BCN-<vessel_code>-<seq>`.
- **Analysis**: Gemini's review of one ticket.
- **Similar tickets**: embedding-based matches across the fleet. **Corpus matches**: matches against past accident investigations.
- **Microlearning**: a one-screen lesson sent to vessels. **Media template**: `text`, `image`, `gif`, `video` (max 6 s).
- **Daily Anchor**: the daily motivation / safety / news card.
- Status enums are UPPER_SNAKE in the API and DB, never translated or renamed in code.

## Shared domain rules
- `onboard_status` (ship owns): `SUBMITTED`, `ACKNOWLEDGED`, `ACTION_IN_PROGRESS`, `RESOLVED_ON_BOARD`. Read-only on shore.
- `shore_status` (shore owns): `NEW` → `IN_REVIEW` (accept) or `REJECTED` (reason required); `IN_REVIEW` → `CLOSED`.
- Severity 1 to 5. ISM categories are `unsafe_act`, `unsafe_condition`,
  `equipment_failure`, `procedure_gap`, validated in `routes/tickets_routes.py`
  and typed in the dashboard's `src/api/types.ts`. Hazard types are a free
  string column server-side and a union type client-side. **Neither is a shared
  enum module yet** — `contract/enums.py` holds only roles, statuses and sync
  event types.
- `ticket_no` is assigned by shore-api from `vessels.code` plus a per-vessel
  sequence.

## Privacy rules (non-negotiable)
- Shore never stores, receives, displays or infers a reporter's identity. Only `reporter_ref` (opaque) and `rank_band`.
- No crew identifier is ever sent to Gemini, Imagen, Veo or the embedding model.
- AI output is labelled "AI generated" with model name and time, and never changes a ticket field or publishes content without an explicit human click.
- `AI_MODE=live` fails loudly when a model is unreachable; it never falls back to
  canned text. Offline stubs (`AI_MODE=fake`) are labelled with a `fake/` model
  prefix so they cannot be mistaken for real output.
- Wellbeing numbers are shown only for groups of 5 or more. shore-api enforces
  this: below 5 it returns `mood: null` with `suppressed: true`, and `/sync/push`
  rejects an aggregate with `count < 5`.
- Where there is nothing to compute from, the API returns `null` — never a
  plausible-looking constant.

## Working rules
- Launch Claude Code from this root folder. Work in one app or service at a time; read that folder's CLAUDE.md first.
- API contract: shore-api builds responses as plain dicts, so `/openapi.json`
  documents requests but **not** response bodies. `apps/beacon-dashboard/src/api/types.ts`
  is the hand-maintained contract — update it in the same change as an endpoint.
- Secrets only in `.env` files (git-ignored). Keep `.env.example` files current.
- Small commits, one concern each, message prefix with scope: `dashboard:`, `shore-api:`, `infra:`, `docs:`.
- Before saying a task is done: run that folder's checks (see its CLAUDE.md) and the end-to-end smoke test `scripts/smoke_e2e.sh`.
- Schema changes need `services/shore-api/scripts/migrate_shore_db.py`:
  `create_all` adds tables but never columns. There is no Alembic yet.
- Don't add dependencies without saying why. Don't build crew-app or edge-server features.

## Run everything locally
```bash
# 1. Config. shore-api reads services/shore-api/.env first, then the repo root.
cp .env.example services/shore-api/.env    # then fill DB + Gemini/Vertex values

# 2. Database: PostgreSQL 16 + pgvector (or point SHORE_DATABASE_URL at a cloud one)
docker compose -f infra/docker-compose.yml up -d

# 3. shore-api on :8001
cd services/shore-api
pip install -r requirements.txt
python scripts/migrate_shore_db.py --embed   # schema + embeddings (idempotent)
python scripts/seed_shore_db.py              # demo data (skip against a populated DB)
python -m uvicorn main:app --host 127.0.0.1 --port 8001 --reload

# 4. Dashboard on :8080
cd apps/beacon-dashboard && npm install && npm run dev

# 5. End-to-end check (the three AI use cases, privacy and transition guards)
./scripts/smoke_e2e.sh
```

Gotchas that cost real time:
- A `DATABASE_URL` exported in your shell **overrides** the `.env` file.
- SQLAlchemy 2.1 resolves a bare `postgresql://` URL to psycopg v3, not psycopg2.
- Set `ALLOW_SQLITE_FALLBACK=false` so an unreachable database fails loudly
  instead of silently becoming a local SQLite file.
- `SIMILARITY_MIN_SCORE` must be **measured** against your embedding model, not
  guessed. See `services/shore-api/CLAUDE.md`.
