# Beacon Dashboard (apps/beacon-dashboard)

Desktop-first web app for the shore fleet safety team. Originally generated in
Lovable (repo `beacon-crew-hub`). Read the root `CLAUDE.md` first, and
`AGENTS.md` in this folder for the architecture rules.

## Stack
**React 19 + TypeScript + Vite 8**, **TanStack Start** with **file-based routing
via TanStack Router** (not React Router), Tailwind **v4**, shadcn/ui, TanStack
Query, TanStack Table, Recharts, lucide-react, i18next.

Package manager: the lockfiles disagree (`bun.lock` and `package-lock.json` are
both present). npm works; `bunfig.toml` holds a 24 h supply-chain guard if you
use bun.

Checks before "done":
```bash
npx tsc --noEmit -p tsconfig.json   # there is no "typecheck" script
npm run lint
npm run test                        # vitest, 18 tests
npm run build
```
And the screen you changed must work against the real shore-api
(`VITE_USE_MOCK=false`).

The dev server runs on **:8080** (the Lovable Vite config picks the port), not
:5173.

## API layer (all data goes through it)
- `src/api/config.ts`: `API_BASE_URL` from `VITE_API_BASE_URL`
  (default `http://localhost:8001/api/v1` — shore-api listens on 8001),
  `USE_MOCK` from `VITE_USE_MOCK` (**default false**: the real API).
- `src/api/client.ts`: fetch wrapper, Bearer JWT, 401 -> login. Reads the
  API's error shape (`detail.error`, `error`, `message`).
- `src/api/endpoints/*.ts`: one file per module — `auth`, `tickets`, `analysis`,
  `messages`, `learnings`, `anchor`, `fleet`, `vessels`, plus `dev` (demo-only
  controls). Every function has a real branch and a mock branch with a
  `// METHOD /path` comment.
- `src/api/types.ts`: mirrors the API. snake_case, exactly as returned.
  Hand-synced — shore-api builds its responses as dicts, so `/openapi.json`
  does not describe them.
- Components never call `fetch` or import mocks; they use hooks in `src/hooks`.

## Screens and the API they use
| Screen | Endpoints |
| --- | --- |
| Login | `POST /auth/login` |
| Ticket queue | `GET /tickets` (filters; a 10 s `updated_since` poll that passes `with_similar_counts=false`) |
| Ticket detail | `GET /tickets/{id}`, `/accept`, `/reject`, `/close`, `GET\|POST /tickets/{id}/messages`, `PATCH /tickets/{id}` |
| AI analysis panel | `GET /tickets/{id}/analysis`, `POST` to re-run, `GET /tickets/{id}/similar` |
| Microlearning studio | `POST /learnings/generate`, `POST /learnings`, `PATCH /learnings/{id}`, `POST /learnings/{id}/media`, `/publish`, `/retract` |
| Fleet overview | `GET /fleet/overview`, `GET /fleet/clusters` |
| Vessels (admin) | `GET /vessels` |

**Daily Anchor has no screen yet.** The API and the client layer are complete
(`src/api/endpoints/anchor.ts`, the `useAnchor*` hooks, the `AnchorCard` types) —
only the UI is missing.

**AI media generation has no UI yet.** `generateLearningMedia` + `getMediaJob`
and the `useGenerateMedia` polling hook exist; the uploader is upload-only. It
also needs Vertex AI, not a Gemini API key.

## AI UX rules
- Every AI block shows "AI generated · {model} · {time}". When
  `analysis.ai_mode === "fake"` the panel also shows an "Offline stub" chip —
  a demo must never read a stub as real Gemini output.
- Suggestions (ISM category, severity) change a field only after the user clicks
  "Apply suggestion", which sends `PATCH /tickets/{id}` with
  `source: "ai_suggestion"`. `auto_applied` from the API is always false.
- Long generation polls a job and never blocks the UI.
- On an AI error show a calm inline message with "Retry"; the API returns
  `{error, code, ai_error}`.

## Honest empty states
The API returns `null` rather than a plausible-looking number when it has
nothing to compute from. The UI must render that, not `0`:
- `median_accept_hours` — null until a ticket has been accepted.
- `learning_ack_rate` — null until a ship reports delivery.
- `wellbeing[].mood` / `.fatigue` — null when `n < 5` (`suppressed: true`).
  **Never show a wellbeing figure for a group under 5.**
- `rank_band`, `original_language`, `last_ship_sync_at` — null when the ship
  did not send one.
Use `t("common.noData")` (an em dash) for these.

## Statuses
UPPER_SNAKE everywhere, matching the API: tickets (`NEW`, `IN_REVIEW`,
`REJECTED`, `CLOSED`) **and** learnings (`DRAFT`, `PUBLISHED`, `RETRACTED`).
i18n keys follow the same casing (`learn.status.DRAFT`). Map labels via i18n;
never rename an enum in the UI layer.

## Microlearning media
Templates are `text`, `image`, `gif`, `video` (video <= 6.0 s). Today the editor
can **upload**; "generate with AI" is wired in the client but has no control.
Client-side checks before upload: image <= 5 MB, video <= 6.0 s (read from a
`<video>` element) and <= 20 MB — these mirror `services/media/processing.py`,
which re-checks server side with ffprobe. Show the 2 MB ship-budget bar.

## Privacy in the UI
No reporter name, ID, filter or export anywhere. The reporter is always
"Reporter". Wellbeing tiles show values only when `n >= 5`.

## Theme
Tailwind/shadcn tokens only, never raw hex in components. The palette lives in
`src/styles.css` as **oklch** custom properties: background `#F5F8FB`, surface
`#FFFFFF`, border `#DCE5EE`, text `#0F2A44` / `#5B7088`, primary Harbor Blue
`#2B6CB0`, secondary Sea Glass `#3AA6A0`, accent Sand `#F3E7D3`, AI surface
`#F0F4FA`. Severity 1-2 `#5BAE86`, 3 `#E2A93B`, 4-5 `#D9665B`. Inter, 14 px card
radius.

## Do not
- Show or request reporter identity.
- Rename status enums or API fields in the UI layer; map labels via i18n.
- Render `0` where the API sent `null`.
- Remove the dev panel (visible only when `USE_MOCK` is true).
