export const API_BASE_URL: string =
  import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000";

/**
 * Point an uploaded-media URL from the edge (photo, voice note, video) at the edge address
 * this app already talks to. The edge cannot see its public host behind the proxy, so it
 * may hand back http://localhost:8000/uploads/... or https://localhost/...; only the
 * /uploads/... or /media/... path is trusted. blob:, data: and other URLs pass through.
 */
export function mediaUrl(url: string | null | undefined): string | undefined {
  if (!url) return undefined;
  if (url.startsWith("blob:") || url.startsWith("data:")) return url;
  const m = url.match(/\/(uploads|media)\/[^?#]+/);
  return m ? `${API_BASE_URL.replace(/\/+$/, "")}${m[0]}` : url;
}

export const USE_MOCK: boolean = (import.meta.env.VITE_USE_MOCK ?? "false") === "true";
