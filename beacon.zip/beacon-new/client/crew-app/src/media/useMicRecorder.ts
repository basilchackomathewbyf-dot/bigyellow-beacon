import { useCallback, useEffect, useRef, useState } from "react";
import { MAX_RECORDING_SECONDS } from "@/lib/rules";

export type MediaError = "denied" | "unavailable" | "insecure" | null;

const pickMime = () => {
  if (typeof MediaRecorder === "undefined") return "";
  return ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg"].find((m) => MediaRecorder.isTypeSupported(m)) ?? "";
};

export const classifyMediaError = (e: unknown): MediaError => {
  if (typeof window !== "undefined" && !window.isSecureContext) return "insecure";
  const name = (e as DOMException)?.name;
  if (name === "NotAllowedError" || name === "SecurityError") return "denied";
  return "unavailable";
};

/** Live microphone recorder with level meter and a hard max length. */
export function useMicRecorder(maxSeconds = MAX_RECORDING_SECONDS) {
  const [recording, setRecording] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [levels, setLevels] = useState<number[]>([]);
  const [blob, setBlob] = useState<Blob | null>(null);
  const [url, setUrl] = useState<string | null>(null);
  const [error, setError] = useState<MediaError>(null);

  const rec = useRef<MediaRecorder | null>(null);
  const stream = useRef<MediaStream | null>(null);
  const ctx = useRef<AudioContext | null>(null);
  const raf = useRef<number>(0);
  const started = useRef(0);
  // True while getUserMedia is pending. A second start() in that window used to open
  // a second microphone stream that nothing ever stopped.
  const starting = useRef(false);
  // stop() pressed before the microphone was ready: stop as soon as it is.
  const stopRequested = useRef(false);
  const unmounted = useRef(false);

  const cleanup = useCallback(() => {
    cancelAnimationFrame(raf.current);
    stream.current?.getTracks().forEach((t) => t.stop());
    stream.current = null;
    void ctx.current?.close().catch(() => {});
    ctx.current = null;
  }, []);

  const stop = useCallback(() => {
    if (starting.current) stopRequested.current = true;
    cancelAnimationFrame(raf.current);
    const r = rec.current;
    if (r && r.state !== "inactive") {
      // Freeze the shown length at the moment of stopping (capped so the edge's
      // 60 s check never rejects a recording that the max-length timer ended).
      setElapsed(Math.min(maxSeconds, (performance.now() - started.current) / 1000));
      r.stop();
    }
    setRecording(false);
  }, [maxSeconds]);

  const start = useCallback(async () => {
    if (starting.current || rec.current?.state === "recording") return;
    starting.current = true;
    stopRequested.current = false;
    setError(null);
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      starting.current = false;
      setError(classifyMediaError(null));
      return;
    }
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      starting.current = false;
      if (stopRequested.current || unmounted.current) { s.getTracks().forEach((t) => t.stop()); return; }
      stream.current = s;
      const mime = pickMime();
      const r = new MediaRecorder(s, mime ? { mimeType: mime } : undefined);
      const parts: BlobPart[] = [];
      r.ondataavailable = (e) => { if (e.data.size) parts.push(e.data); };
      r.onstop = () => {
        cleanup();
        if (rec.current === r) rec.current = null;
        if (unmounted.current) return;
        const b = new Blob(parts, { type: r.mimeType || mime || "audio/webm" });
        setBlob(b);
        setUrl((old) => { if (old) URL.revokeObjectURL(old); return URL.createObjectURL(b); });
      };
      rec.current = r;

      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ac = new AC();
      ctx.current = ac;
      void ac.resume().catch(() => {});
      const an = ac.createAnalyser();
      an.fftSize = 256;
      ac.createMediaStreamSource(s).connect(an);
      const data = new Uint8Array(an.frequencyBinCount);

      // No timeslice: Safari's MediaRecorder produces crackly audio/mp4 when asked for
      // 250 ms chunks. The whole recording arrives in one dataavailable on stop.
      r.start();
      started.current = performance.now();
      setRecording(true);
      setElapsed(0);
      setLevels([]);
      let lastPush = 0;
      const tick = (t: number) => {
        an.getByteTimeDomainData(data);
        let sum = 0;
        for (const v of data) sum += ((v - 128) / 128) ** 2;
        const rms = Math.min(1, Math.sqrt(sum / data.length) * 3.2);
        if (t - lastPush > 70) { setLevels((l) => [...l.slice(-47), rms]); lastPush = t; }
        const secs = (performance.now() - started.current) / 1000;
        setElapsed(Math.min(maxSeconds, secs));
        if (secs >= maxSeconds) { stop(); return; }
        raf.current = requestAnimationFrame(tick);
      };
      raf.current = requestAnimationFrame(tick);
    } catch (e) {
      starting.current = false;
      cleanup();
      setRecording(false);
      setError(classifyMediaError(e));
    }
  }, [cleanup, maxSeconds, stop]);

  const discard = useCallback(() => {
    setBlob(null);
    setUrl((old) => { if (old) URL.revokeObjectURL(old); return null; });
    setElapsed(0);
    setLevels([]);
  }, []);

  useEffect(() => {
    unmounted.current = false;
    stopRequested.current = false;
    return () => {
      unmounted.current = true;
      stopRequested.current = true;
      if (rec.current && rec.current.state !== "inactive") rec.current.stop();
      cleanup();
    };
  }, [cleanup]);

  return { recording, elapsed, levels, blob, url, error, start, stop, discard, maxSeconds };
}
